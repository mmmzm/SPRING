package com.pcwk.ehr.login.service;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.login.domain.Login;
import com.pcwk.ehr.mapper.LoginMapper;
import com.pcwk.ehr.mapper.UserMapper;
import com.pcwk.ehr.user.domain.Level;
import com.pcwk.ehr.user.domain.User;

@RunWith(SpringRunner.class) //스프링 컨텍스트 프레임워크의 JUnit확장기능 지정
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml",
                                   "file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" 		
})
@FixMethodOrder(MethodSorters.NAME_ASCENDING) //메소드 수행 순서: method ASCENDING ex)a~z
public class LoginServiceImplTest implements PLog{
	@Autowired
	ApplicationContext context;
	
	@Autowired
	LoginMapper loginMapper;
	
	@Autowired
	LoginService  loginService;
	
	@Autowired
	UserMapper userMapper;	
	
	Login   login01;
	User    userVO01;
	
	
	@Before
	public void setUp() throws Exception {
		log.debug("┌─────────────────────────────────────────────────────────┐");
		log.debug("│ tearDown()                                              │");
		log.debug("└─────────────────────────────────────────────────────────┘");
		
		//전체 삭제
		userMapper.deleteAll();
		
		login01 = new Login("james01", "4321");
		userVO01= new User("james01","이상무01","4321","2002/12/31",Level.BASIC,1,0,"jamesol@paran.com","sysdate사용");
				
	}

	@Test
	public void idPasswordCheck() throws Exception {
		//2. 데이터 1건 입력
		//3. 단건조회
		//4. 비교
		//5. id/비번 확인
		int count = userMapper.getCount();
		assertEquals(0,count);			
		
		//2 등록
		int flag = userMapper.doSave(userVO01);
		assertEquals(1, flag);
		assertEquals(userMapper.getCount(), 1);		
		
		//3
		User outVO = userMapper.doSelectOne(userVO01);
		assertNotNull(outVO);//return User Null check
		//4
		isSameUser(userVO01, outVO);		
		
		//5
		login01.setUserId("아이디 불일치");
		//id확인
		int idPasswordCnt = this.loginService.idPasswordCheck(login01);
		assertEquals(10, idPasswordCnt);
		
		//비번확인
		login01.setUserId("james01");
		login01.setPassword("비번 불일치");
		idPasswordCnt = this.loginService.idPasswordCheck(login01);
		assertEquals(20, idPasswordCnt);
		
		//id비번 일치
		login01.setUserId("james01");
		login01.setPassword("4321");
		idPasswordCnt = this.loginService.idPasswordCheck(login01);
		assertEquals(30, idPasswordCnt);		
		
		
	}
	
	public void isSameUser(User userVO, User outVO) {
		assertEquals(userVO.getUserId(), outVO.getUserId());
		assertEquals(userVO.getName(), outVO.getName());
		assertEquals(userVO.getPassword(), outVO.getPassword());
		assertEquals(userVO.getBirthday(),outVO.getBirthday());	
		
		assertEquals(userVO.getLevel(), outVO.getLevel());
		assertEquals(userVO.getLogin(), outVO.getLogin());
		assertEquals(userVO.getRecommend(), outVO.getRecommend());
		assertEquals(userVO.getEmail(),outVO.getEmail());
		
	}
	@After
	public void tearDown() throws Exception {
		log.debug("┌─────────────────────────────────────────────────────────┐");
		log.debug("│ tearDown()                                              │");
		log.debug("└─────────────────────────────────────────────────────────┘");
	}

	@Ignore
	@Test
	public void beans() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ beans()                                  │");
		log.debug("└──────────────────────────────────────────┘");
		log.debug("context:" + context);
		log.debug("loginMapper:" + loginMapper);
		log.debug("loginService:" + loginService);
		log.debug("userMapper:" + userMapper);
		assertNotNull(context);
		assertNotNull(loginMapper);
		assertNotNull(loginService);
		assertNotNull(userMapper);
	}

}
