package com.pcwk.ehr.login.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.pcwk.ehr.cmn.Message;
import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.login.domain.Login;
import com.pcwk.ehr.mapper.UserMapper;
import com.pcwk.ehr.user.domain.Level;
import com.pcwk.ehr.user.domain.User;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class) // 스프링 컨텍스트 프레임워크의 JUnit확장기능 지정
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml" })
@FixMethodOrder(MethodSorters.NAME_ASCENDING) // 메소드 수행 순서: method ASCENDING ex)a~z
public class LoginControllerTest implements PLog {

	@Autowired
	WebApplicationContext webApplicationContext;

	// 브라우저 대신 Mock
	MockMvc mockMvc;

	@Autowired
	UserMapper userMapper;

	MockHttpSession session;
	
	
	Login login01;
	User userVO01;



	@Before
	public void setUp() throws Exception {
		log.debug("┌─────────────────────────────────────────────────────────┐");
		log.debug("│ setUp()                                                 │");
		log.debug("└─────────────────────────────────────────────────────────┘");
		// 전체 삭제
		userMapper.deleteAll();

		login01 = new Login("james01", "4321");
		userVO01 = new User("james01", "이상무01", "4321", "2002/12/31", Level.BASIC, 1, 0, "jamesol@paran.com",
				"sysdate사용");

		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		session = new MockHttpSession();
	}

	@Test
	public void loginInfoPasswordFail() throws Exception {
		//사용자 등록
		int flag = userMapper.doSave(userVO01);
		assertEquals(1, flag);
		//등록 정보로 로그인
		
		//호출방식, URL, param 저장
		MockHttpServletRequestBuilder  requestBuilder = 
				  MockMvcRequestBuilders.post("/login/loginInfo.do")
				  .param("userId", login01.getUserId())
				  .param("password", "비번오류")
				  .session(session)
				  ;
		
		//호출
		ResultActions resultActions =mockMvc.perform(requestBuilder)
				.andExpect(MockMvcResultMatchers.content().contentType("text/plain;charset=UTF-8"))
				.andExpect(status().isOk());
		   
		String jsonResult = resultActions.andDo(print())
							.andReturn()
							.getResponse().getContentAsString();
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│jsonResult │"+jsonResult);
		log.debug("└──────────────────────────────────────────┘");		
		
		Message resultMessage = new Gson().fromJson(jsonResult, Message.class);
		assertEquals(20, resultMessage.getMessagId());
		assertEquals("비번을 확인 하세요.", resultMessage.getMessageContents());
		
		
		//session
		User user=(User) session.getAttribute("user");
		assertNull(user);
		
	}	
	@Ignore
	@Test
	public void loginInfoIdFail() throws Exception {
		//사용자 등록
		int flag = userMapper.doSave(userVO01);
		assertEquals(1, flag);
		//등록 정보로 로그인
		
		//호출방식, URL, param 저장
		MockHttpServletRequestBuilder  requestBuilder = 
				  MockMvcRequestBuilders.post("/login/loginInfo.do")
				  .param("userId", "아이디 오류")
				  .param("password", login01.getPassword())
				  .session(session)
				  ;
		
		//호출
		ResultActions resultActions =mockMvc.perform(requestBuilder)
				.andExpect(MockMvcResultMatchers.content().contentType("text/plain;charset=UTF-8"))
				.andExpect(status().isOk());
		   
		String jsonResult = resultActions.andDo(print())
							.andReturn()
							.getResponse().getContentAsString();
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│jsonResult │"+jsonResult);
		log.debug("└──────────────────────────────────────────┘");		
		
		Message resultMessage = new Gson().fromJson(jsonResult, Message.class);
		assertEquals(10, resultMessage.getMessagId());
		assertEquals("아이디를 확인 하세요.", resultMessage.getMessageContents());
		
		
		//session
		User user=(User) session.getAttribute("user");
		assertNull(user);
		
	}
	
	@Ignore
	@Test
	public void loginInfo() throws Exception {
		//사용자 등록
		int flag = userMapper.doSave(userVO01);
		assertEquals(1, flag);
		//등록 정보로 로그인
		
		//호출방식, URL, param 저장
		MockHttpServletRequestBuilder  requestBuilder = 
				  MockMvcRequestBuilders.post("/login/loginInfo.do")
				  .param("userId", login01.getUserId())
				  .param("password", login01.getPassword())
				  .session(session)
				  ;
		
		//호출
		ResultActions resultActions =mockMvc.perform(requestBuilder)
				.andExpect(MockMvcResultMatchers.content().contentType("text/plain;charset=UTF-8"))
				.andExpect(status().isOk());
		   
		String jsonResult = resultActions.andDo(print())
							.andReturn()
							.getResponse().getContentAsString();
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│jsonResult │"+jsonResult);
		log.debug("└──────────────────────────────────────────┘");		
		
		Message resultMessage = new Gson().fromJson(jsonResult, Message.class);
		assertEquals(30, resultMessage.getMessagId());
		assertEquals("아이디/비번일치!", resultMessage.getMessageContents());
		
		
		//session
		User user=(User) session.getAttribute("user");
		assertNotNull(user);
		
		assertEquals("이상무01", user.getName());
	}

	@After
	public void tearDown() throws Exception {
		log.debug("┌─────────────────────────────────────────────────────────┐");
		log.debug("│ tearDown()                                              │");
		log.debug("└─────────────────────────────────────────────────────────┘");
	}

	@Ignore
	@Test
	public void beans() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ beans()                                  │");
		log.debug("└──────────────────────────────────────────┘");

		log.debug("webApplicationContext:" + webApplicationContext);
		log.debug("mockMvc:" + mockMvc);
		log.debug("userMapper:" + userMapper);

		assertNotNull(webApplicationContext);
		assertNotNull(mockMvc);
		assertNotNull(userMapper);
	}

}
