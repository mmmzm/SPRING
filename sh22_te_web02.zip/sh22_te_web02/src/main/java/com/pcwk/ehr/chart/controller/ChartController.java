package com.pcwk.ehr.chart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.pcwk.ehr.chart.domain.Pizza;
import com.pcwk.ehr.cmn.PLog;

@Controller
@RequestMapping("chart")
public class ChartController implements PLog {

	public ChartController() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ ChartController()                        │");
		log.debug("└──────────────────────────────────────────┘");
	}

	
	//화면 loading
	@GetMapping("/line.do")
	public String lineView() {
		String viewName = "chart/line";
		log.debug("viewName:" + viewName);
		return viewName;		
	}
	
	
	//화면 loading
	@GetMapping("/pie_data.do")
	public String pieDataView() {
		String viewName = "chart/pie_data";
		log.debug("viewName:" + viewName);
		return viewName;		
	}
	
	//data로드: 비동기통신
	@PostMapping(value="/pie_data.do", produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String pieDataw() {
		String jsonData = "";
		/* 배열에 배열
		 * [
		      ['Mushrooms', 3],
		      ['Onions', 1],
		      ['Olives', 1],
		      ['Zucchini', 1],
		      ['Pepperoni', 2]
		    ]
		 */
		
		Pizza  pizza01=new Pizza("버섯", 3);
		Pizza  pizza02=new Pizza("양파", 1);
		Pizza  pizza03=new Pizza("올리브", 1);
		Pizza  pizza04=new Pizza("주키니", 1);
		Pizza  pizza05=new Pizza("햄", 2);
		
		List<Pizza> list=new ArrayList<Pizza>();
		list.add(pizza01);
		list.add(pizza02);
		list.add(pizza03);
		list.add(pizza04);
		list.add(pizza05);
		
		JsonArray  mainArray=new JsonArray();
		for(Pizza vo  :list) {
			JsonArray  childArray=new JsonArray();
			childArray.add(vo.getTopping());
			childArray.add(vo.getSlices());
			
			mainArray.add(childArray);
		}
		
		
		jsonData = mainArray.toString();
		log.debug("1.jsonData:" + jsonData);
		
		return jsonData;
	}
	
	
	
	
	
	
	@GetMapping("/pie.do")
	public String pieView() {
		String viewName = "chart/pie";
		log.debug("viewName:" + viewName);
		return viewName;		
	}
	
	   
}
