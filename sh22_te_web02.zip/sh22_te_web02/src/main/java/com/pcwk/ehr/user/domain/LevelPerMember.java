package com.pcwk.ehr.user.domain;

import com.pcwk.ehr.cmn.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor  //default 생성자
@AllArgsConstructor //인자있는 생성자
public class LevelPerMember extends DTO {
	
	private int year;
	private String levelName;
	private int count;
	
}
