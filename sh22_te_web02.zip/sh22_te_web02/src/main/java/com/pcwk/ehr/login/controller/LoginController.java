package com.pcwk.ehr.login.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.GsonBuilder;
import com.pcwk.ehr.cmn.Message;
import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.login.domain.Login;
import com.pcwk.ehr.login.service.LoginService;
import com.pcwk.ehr.user.domain.User;

@Controller
@RequestMapping("login")
public class LoginController implements PLog {

	@Autowired
	LoginService loginService;

	public LoginController() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ LoginController()                        │");
		log.debug("└──────────────────────────────────────────┘");
	}

	// 화면
	@GetMapping("/login.do")
	public String loginView() {
		String viewName = "login/login";
		log.debug("viewName:" + viewName);
		return viewName;
	}

	@RequestMapping(value = "/logout.do", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String logout(HttpSession httpSession) {
		String jsonString = "";
		log.debug("logout()");
		
		String loginOutMessage = "^^";
		int    flag = 0;
		if( null != httpSession.getAttribute("user")) {
			httpSession.invalidate();
			
			loginOutMessage = "로그아웃 되었습니다.";
			flag = 1;
		}
		
		Message message=new Message(flag, loginOutMessage);
		jsonString = new GsonBuilder().setPrettyPrinting().create().toJson(message);
		log.debug("3.jsonString:" + jsonString);		
		
		return jsonString;
	}

	@RequestMapping(value = "/loginInfo.do", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String loginInfo(Login inVO, HttpSession httpSession) throws SQLException {
		String jsonString = "";

		

		
		log.debug("1 param:" + inVO);
		int checkCount = loginService.idPasswordCheck(inVO);

		String loginMessage = "";
		if (10 == checkCount) {// 아이디를 확인 하세요.
			loginMessage = "아이디를 확인 하세요.";
		} else if (20 == checkCount) {// 비번을 확인 하세요.
			loginMessage = "비번을 확인 하세요.";
		} else if (30 == checkCount) {
			loginMessage = "아이디/비번일치!";

			// 회원정보
			User user = loginService.loginInfo(inVO);
			if (null != user) {
				httpSession.setAttribute("user", user);
			}
		}

		Message message = new Message(checkCount, loginMessage);

		jsonString = new GsonBuilder().setPrettyPrinting().create().toJson(message);
		log.debug("3.jsonString:" + jsonString);

		return jsonString;
	}

}
