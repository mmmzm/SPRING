package com.pcwk.ehr.except.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.login.domain.Login;

@Controller
@RequestMapping("except")
public class ExceptionController implements PLog {

	public ExceptionController() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ ExceptionController()                    │");
		log.debug("└──────────────────────────────────────────┘");
	}

	// http://localhost:8080/ehr/except/nullPointerError.do
	@GetMapping(value = "/nullPointerError.do")
	public String nullPointerError(Login login) {

		String viewName = "main/main";

		if (null == login.getUserId() || "".equals(login.getUserId())) {

			log.debug("┌──────────────────────────────────────────┐");
			log.debug("│ NullPointerException()                   │");
			log.debug("└──────────────────────────────────────────┘");

			throw new NullPointerException("아이디를 입력 하세요.");
		}

		return viewName;
	}

	// http://localhost:8080/ehr/except/arithmeticError.do
	@GetMapping(value = "/arithmeticError.do")
	public String arithmeticError(Login login) {

		String viewName = "main/main";

		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ ArithmeticException()                    │");
		log.debug("└──────────────────────────────────────────┘");
		try {
			int age = 22;
			int newAge = age / 0;
		} catch (ArithmeticException e) {
			throw new ArithmeticException(e.getMessage());
		}

		return viewName;
	}

}
