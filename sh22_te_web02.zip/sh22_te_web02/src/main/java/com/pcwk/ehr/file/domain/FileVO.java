package com.pcwk.ehr.file.domain;

import com.pcwk.ehr.cmn.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor  //Default생성자
@AllArgsConstructor //인자있는 생성자
@Getter             
@Setter
@ToString
public class FileVO extends DTO {
	
  private String orgFileName; //원본 파일명
  private String saveFileName;//저장 파일명
  private String savePath;    //저장 경로
	
  private long fileSize;      //파일크기
  private String extension; //확장자
  
}
