package com.pcwk.ehr.data.controller;

import java.util.concurrent.ScheduledExecutorService;
import java.awt.Event;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.GsonBuilder;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.pcwk.ehr.cmn.PLog;

@RestController
public class DataController implements PLog {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

	private ObjectMapper objectMapper = new ObjectMapper();

	int i = 1;

	//
	public DataController() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ DataController()                         │");
		log.debug("└──────────────────────────────────────────┘");
	}

	//, produces = "text/plain;charset=UTF-8"
	@RequestMapping(value = "/data"
			, method = RequestMethod.GET
			, produces = "text/event-stream;charset=UTF-8")
	public SseEmitter streamData() {
		log.debug("┌──────────────────────────────────────────┐");
		log.debug("│ streamData()                             │");
		log.debug("└──────────────────────────────────────────┘");

		SseEmitter emitter = new SseEmitter();

		scheduler.scheduleAtFixedRate(() -> {

			try {
				String data = fetchDataFromDB();
				
				String jsonData = new GsonBuilder().setPrettyPrinting().create().toJson(data + "_" + i);

				log.debug("jsonData:" + jsonData);
				i++;
				// emitter.send(objectMapper.writeValueAsString(data+"_"+i));
	            SseEmitter.SseEventBuilder event = SseEmitter.event()
	                    .name("message")
	                    .data("\"8989_jjk\"", MediaType.APPLICATION_JSON_UTF8)
	                    .id(String.valueOf(i));
	            
	            log.debug("event:" + event.toString());
	            emitter.send(event); 
			} catch (IOException e) {
				emitter.completeWithError(e);
			}
		}, 0, 10, TimeUnit.SECONDS);
 
		return emitter;
	}

	private String fetchDataFromDB() {
		// james_0000001
		String result = "";
		StringBuilder sb = new StringBuilder(100);
		sb.append("  SELECT name       \n");
		sb.append("  FROM              \n");
		sb.append("      member        \n");
		sb.append("  WHERE user_id = ? \n");

		log.debug("sql:\n" + sb.toString());

		// param
		Object[] args = { "james_0000001" };

		result = jdbcTemplate.queryForObject(sb.toString(), String.class, args);
		log.debug("result:" + result);

		return result;
	}

}
