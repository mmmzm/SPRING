package com.pcwk.ehr.chart.domain;

import com.pcwk.ehr.cmn.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor  //default 생성자
@AllArgsConstructor //인자있는 생성자
public class Pizza extends DTO {

	private String topping;//토핑
	private int    slices; //슬라이스
	
	
	
	
}
