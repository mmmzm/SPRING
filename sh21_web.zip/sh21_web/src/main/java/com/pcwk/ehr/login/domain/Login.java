package com.pcwk.ehr.login.domain;

import com.pcwk.ehr.cmn.DTO;

import lombok.Data;


@Data
public class Login  extends DTO {
	
	private String userId   ;//사용자id
	private String password ;//비밀번호	
	
	public Login() {

	}

	public Login(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	
	

}
